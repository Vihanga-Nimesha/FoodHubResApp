package com.example.tablereservation

import android.content.Intent
import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class tableReservation : AppCompatActivity() {

     var num = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_table_reservation)

        val reserveBtn = findViewById<Button>(R.id.nextBtn)
        reserveBtn.setBackgroundColor(resources.getColor(R.color.black))
        reserveBtn.setTextColor(resources.getColor(R.color.white))

        // Click the next button to move to another XML file
        val backArrow = findViewById<ImageView>(R.id.backarrow)
        backArrow.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        val Add = findViewById<ImageView>(R.id.add_number)
        val Remove = findViewById<ImageView>(R.id.remove_number)
        val changingTextBox = findViewById<TextView>(R.id.changing_numbers)

        Add.setOnClickListener{
           num += 2

            changingTextBox.text = num.toString()


            val drawableResource = when (num){
                2 -> R.drawable.two_space
                4 -> R.drawable.four_space
                6 -> R.drawable.six_space
                else -> R.drawable.empty
            }

            val tables: ImageView = findViewById(R.id.tables)
            tables.setImageResource(drawableResource)

        }

        Remove.setOnClickListener{
            num -= 2
            changingTextBox.text = num.toString()

            val drawableResource = when (num){
                0 -> R.drawable.empty
                2 -> R.drawable.two_space
                4 -> R.drawable.four_space
                6 -> R.drawable.six_space
                else -> R.drawable.empty
            }

            val tables: ImageView = findViewById(R.id.tables)
            tables.setImageResource(drawableResource)
        }


    }
}
