package com.example.tablereservation

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val lunchBtn = findViewById<Button>(R.id.LunchBtn)
        val dinnerBtn = findViewById<Button>(R.id.DinnerBtn)

        val reserveBtn = findViewById<Button>(R.id.nextBtn)
        reserveBtn.setBackgroundColor(resources.getColor(R.color.black))
        reserveBtn.setTextColor(resources.getColor(R.color.white))

        lunchBtn.setOnClickListener{
            lunchBtn.setBackgroundColor(resources.getColor(R.color.yellow))
            lunchBtn.setTextColor(resources.getColor(R.color.white))

            dinnerBtn.setBackgroundColor(resources.getColor((R.color.white)))
            dinnerBtn.setTextColor(resources.getColor(R.color.black))

            LunchTimes(it)
        }


        dinnerBtn.setOnClickListener{
            dinnerBtn.setBackgroundColor(resources.getColor(R.color.yellow))
            dinnerBtn.setTextColor(resources.getColor(R.color.white))

            lunchBtn.setBackgroundColor(resources.getColor(R.color.white))
            lunchBtn.setTextColor(resources.getColor(R.color.black))

            dinnerTimes(it)
        }

        // changing bg color of btn when clicked
        val timeOneBtn = findViewById<Button>(R.id.time1)
        val timeTwoBtn = findViewById<Button>(R.id.time2)
        val timeThreeBtn = findViewById<Button>(R.id.time3)
        val timeFourBtn = findViewById<Button>(R.id.time4)
        val timeFiveBtn = findViewById<Button>(R.id.time5)
        val timeSixBtn = findViewById<Button>(R.id.time6)
        val timeSevenBtn = findViewById<Button>(R.id.time7)
        val timeEightBtn = findViewById<Button>(R.id.time8)
        val timeNineBtn = findViewById<Button>(R.id.time9)
        val timeTenBtn = findViewById<Button>(R.id.time10)
        val timeElevenBtn = findViewById<Button>(R.id.time11)



        timeOneBtn.setOnClickListener {
            timeOneBtn.setBackgroundColor(resources.getColor(R.color.selectedYellow))

            timeTwoBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeThreeBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeFourBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeFiveBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeSixBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))

        }

        timeTwoBtn.setOnClickListener {
            timeTwoBtn.setBackgroundColor(resources.getColor(R.color.selectedYellow))

            timeOneBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeThreeBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeFourBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeFiveBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeSixBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))

        }

        timeThreeBtn.setOnClickListener {
            timeThreeBtn.setBackgroundColor(resources.getColor(R.color.selectedYellow))

            timeOneBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeTwoBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeFourBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeFiveBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeSixBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))

        }

        timeFourBtn.setOnClickListener {
            timeFourBtn.setBackgroundColor(resources.getColor(R.color.selectedYellow))

            timeOneBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeTwoBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeThreeBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeFiveBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeSixBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
        }

        timeFiveBtn.setOnClickListener {
            timeFiveBtn.setBackgroundColor(resources.getColor(R.color.selectedYellow))

            timeOneBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeTwoBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeThreeBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeFourBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeSixBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
        }

        timeSixBtn.setOnClickListener {
            timeSixBtn.setBackgroundColor(resources.getColor(R.color.selectedYellow))

            timeOneBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeTwoBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeThreeBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeFourBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeFiveBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
        }

        timeSevenBtn.setOnClickListener {
            timeSevenBtn.setBackgroundColor(resources.getColor(R.color.selectedYellow))

            timeEightBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeNineBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeTenBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeElevenBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))

        }

        timeEightBtn.setOnClickListener {
            timeEightBtn.setBackgroundColor(resources.getColor(R.color.selectedYellow))

            timeSevenBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeNineBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeTenBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeElevenBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
        }

        timeNineBtn.setOnClickListener {
            timeNineBtn.setBackgroundColor(resources.getColor(R.color.selectedYellow))

            timeSevenBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeEightBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeTenBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeElevenBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
        }

        timeTenBtn.setOnClickListener {
            timeTenBtn.setBackgroundColor(resources.getColor(R.color.selectedYellow))

            timeSevenBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeEightBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeNineBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeElevenBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
        }

        timeElevenBtn.setOnClickListener {
            timeElevenBtn.setBackgroundColor(resources.getColor(R.color.selectedYellow))

            timeSevenBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeEightBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeNineBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
            timeTenBtn.setBackgroundColor(resources.getColor(R.color.LightYellow))
        }

        // Click the next button to move to another XML file
        val nextButton = findViewById<Button>(R.id.nextBtn)

        nextButton.setOnClickListener {

            // if(timeOneBtn.isClickable || timeTwoBtn.isClickable || timeThreeBtn.isClickable || timeFourBtn.isClickable || timeFiveBtn.isClickable || timeSixBtn.isClickable || timeSevenBtn.isClickable || timeEightBtn.isClickable || timeNineBtn.isClickable || timeTenBtn.isClickable || timeElevenBtn.isClickable){
                val intent = Intent(this, tableReservation::class.java)
                startActivity(intent)

        }




    }



    private fun LunchTimes(view: View) {
        //locating the time buttons from the .xml file
        val timeOneBtn = findViewById<Button>(R.id.time1)
        val timeTwoBtn = findViewById<Button>(R.id.time2)
        val timeThreeBtn = findViewById<Button>(R.id.time3)
        val timeFourBtn = findViewById<Button>(R.id.time4)
        val timeFiveBtn = findViewById<Button>(R.id.time5)
        val timeSixBtn = findViewById<Button>(R.id.time6)
        val timeSevenBtn = findViewById<Button>(R.id.time7)
        val timeEightBtn = findViewById<Button>(R.id.time8)
        val timeNineBtn = findViewById<Button>(R.id.time9)
        val timeTenBtn = findViewById<Button>(R.id.time10)
        val timeElevenBtn = findViewById<Button>(R.id.time11)

        timeOneBtn.visibility = View.VISIBLE
        timeTwoBtn.visibility = View.VISIBLE
        timeThreeBtn.visibility = View.VISIBLE
        timeFourBtn.visibility = View.VISIBLE
        timeFiveBtn.visibility = View.VISIBLE
        timeSixBtn.visibility = View.VISIBLE

        timeSevenBtn.visibility = View.GONE
        timeEightBtn.visibility = View.GONE
        timeNineBtn.visibility = View.GONE
        timeTenBtn.visibility = View.GONE
        timeElevenBtn.visibility = View.GONE

        timeOneBtn.setTextColor(resources.getColor(R.color.black))
        timeTwoBtn.setTextColor(resources.getColor(R.color.black))
        timeThreeBtn.setTextColor(resources.getColor(R.color.black))
        timeFourBtn.setTextColor(resources.getColor(R.color.black))
        timeFiveBtn.setTextColor(resources.getColor(R.color.black))
        timeSixBtn.setTextColor(resources.getColor(R.color.black))

    }

    private fun  dinnerTimes(view: View){
        val timeOneBtn = findViewById<Button>(R.id.time1)
        val timeTwoBtn = findViewById<Button>(R.id.time2)
        val timeThreeBtn = findViewById<Button>(R.id.time3)
        val timeFourBtn = findViewById<Button>(R.id.time4)
        val timeFiveBtn = findViewById<Button>(R.id.time5)
        val timeSixBtn = findViewById<Button>(R.id.time6)
        val timeSevenBtn = findViewById<Button>(R.id.time7)
        val timeEightBtn = findViewById<Button>(R.id.time8)
        val timeNineBtn = findViewById<Button>(R.id.time9)
        val timeTenBtn = findViewById<Button>(R.id.time10)
        val timeElevenBtn = findViewById<Button>(R.id.time11)

        timeSevenBtn.visibility = View.VISIBLE
        timeEightBtn.visibility = View.VISIBLE
        timeNineBtn.visibility = View.VISIBLE
        timeTenBtn.visibility = View.VISIBLE
        timeElevenBtn.visibility = View.VISIBLE

        timeOneBtn.visibility = View.GONE
        timeTwoBtn.visibility = View.GONE
        timeThreeBtn.visibility = View.GONE
        timeFourBtn.visibility = View.GONE
        timeFiveBtn.visibility = View.GONE
        timeSixBtn.visibility = View.GONE

        timeSevenBtn.setTextColor(resources.getColor(R.color.black))
        timeEightBtn.setTextColor(resources.getColor(R.color.black))
        timeNineBtn.setTextColor(resources.getColor(R.color.black))
        timeTenBtn.setTextColor(resources.getColor(R.color.black))
        timeElevenBtn.setTextColor(resources.getColor(R.color.black))
    }
}